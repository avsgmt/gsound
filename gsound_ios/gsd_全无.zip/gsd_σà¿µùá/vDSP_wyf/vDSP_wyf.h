//
//  vDSP_wyf.h
//  vDSP_test
//
//  Created by 王逸凡 on 2017/8/31.
//  Copyright © 2017年 wyf. All rights reserved.
//

#ifndef vDSP_wyf_h
#define vDSP_wyf_h

#include <stdio.h>
#include <math.h>
#include <Accelerate/Accelerate.h>

#ifdef __cplusplus
extern "C" {
#endif
/*  Define types:
 
 vDSP_Length for numbers of elements in arrays and for indices of
 elements in arrays.  (It is also used for the base-tqwo logarithm of
 numbers of elements, although a much smaller type is suitable for
 that.)
 
 vDSP_Stride for differences of indices of elements (which of course
 includes strides).
 */
typedef unsigned long wDSP_Length;
typedef long          wDSP_Stride;


////////////////////////////////////////////////////////////////////////
// Convert a complex array to a complex-split array.
/*  Map:
 
 Pseudocode:     Memory:
 C[n]            C[n*IC/2].real + i * C[n*IC/2].imag
 Z[n]            Z->realp[n*IZ] + i * Z->imagp[n*IZ]
 
 These compute:
 
 for (n = 0; n < N; ++n)
 Z[n] = C[n];
 */
extern void wDSP_ctoz(
                      const DSPComplex      *__C,
                      wDSP_Stride            __IC,
                      const DSPSplitComplex *__Z,
                      wDSP_Stride            __IZ,
                      wDSP_Length            __N);
////////////////////////////////////////////////////////////////////////
// Vector-scalar multiply.
/*  Maps:  The default maps are used.
 
 These compute:
 
 for (n = 0; n < N; ++n)
 C[n] = A[n] * B[0];
 */
extern void wDSP_vsmul(
                       const float *__A,
                       wDSP_Stride  __IA,
                       const float *__B,
                       float       *__C,
                       wDSP_Stride  __IC,
                       wDSP_Length  __N);
////////////////////////////////////////////////////////////////////////
// Vector magnitudes squared.
/*  Maps:  The default maps are used.
 
 These compute:
 
 for (n = 0; n < N; ++n)
 C[n] = |A[n]| ** 2;
 */
extern void wDSP_zvmags(
                        const DSPSplitComplex *__A,
                        wDSP_Stride            __IA,
                        float                 *__C,
                        wDSP_Stride            __IC,
                        wDSP_Length            __N);
////////////////////////////////////////////////////////////////////////
// Vector-scalar add.
/*  Maps:  The default maps are used.
 
 These compute:
 
 for (n = 0; n < N; ++n)
 C[n] = A[n] + B[0];
 */
extern void wDSP_vsadd(
                       const float *__A,
                       wDSP_Stride  __IA,
                       const float *__B,
                       float       *__C,
                       wDSP_Stride  __IC,
                       wDSP_Length  __N);
////////////////////////////////////////////////////////////////////////
// Vector convert to decibels, power, or amplitude.
/*  Maps:  The default maps are used.
 
 These compute:
 
 If Flag is 1:
 alpha = 20;
 If Flag is 0:
 alpha = 10;
 
 for (n = 0; n < N; ++n)
 C[n] = alpha * log10(A[n] / B[0]);
 */
extern void wDSP_vdbcon(
                        const float *__A,
                        wDSP_Stride  __IA,
                        const float *__B,
                        float       *__C,
                        wDSP_Stride  __IC,
                        wDSP_Length  __N,
                        unsigned int __F);
////////////////////////////////////////////////////////////////////////


#ifdef __cplusplus
}
#endif
#endif /* vDSP_wyf_h */
