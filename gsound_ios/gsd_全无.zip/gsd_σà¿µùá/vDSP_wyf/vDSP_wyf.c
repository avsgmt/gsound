//
//  vDSP_wyf.c
//  vDSP_test
//
//  Created by 王逸凡 on 2017/8/31.
//  Copyright © 2017年 wyf. All rights reserved.
//

#include "vDSP_wyf.h"

#ifdef __cplusplus
extern "C" {
#endif
////////////////////////////////////////////////////////////////////////
// Convert a complex array to a complex-split array.
/*  Map:
 
 Pseudocode:     Memory:
 C[n]            C[n*IC/2].real + i * C[n*IC/2].imag
 Z[n]            Z->realp[n*IZ] + i * Z->imagp[n*IZ]
 
 These compute:
 
 for (n = 0; n < N; ++n)
 Z[n] = C[n];
 */
extern void wDSP_ctoz(
                      const DSPComplex      *__C,
                      wDSP_Stride            __IC,
                      const DSPSplitComplex *__Z,
                      wDSP_Stride            __IZ,
                      wDSP_Length            __N)
{
    for (int n = 0; n < __N; ++n){
        __Z->realp[n*__IZ] = __C[n*__IC/2].real;
        __Z->imagp[n*__IZ] = __C[n*__IC/2].imag;
    }
}

////////////////////////////////////////////////////////////////////////
// Vector magnitudes squared.
/*  Maps:  The default maps are used.
 
 These compute:
 
 for (n = 0; n < N; ++n)
 C[n] = |A[n]| ** 2;
 */
extern void wDSP_zvmags(
                        const DSPSplitComplex *__A,
                        wDSP_Stride            __IA,
                        float                 *__C,
                        wDSP_Stride            __IC,
                        wDSP_Length            __N)
{
    for (int n = 0; n < __N; ++n){
        __C[n] = powf(__A->realp[n],2)+pow(__A->imagp[n],2);
    }
    
}

////////////////////////////////////////////////////////////////////////
// Vector-scalar add.
/*  Maps:  The default maps are used.
 
 These compute:
 
 for (n = 0; n < N; ++n)
 C[n] = A[n] + B[0];
 */
void wDSP_vsadd(
                const float *__A,
                wDSP_Stride  __IA,
                const float *__B,
                float       *__C,
                wDSP_Stride  __IC,
                wDSP_Length  __N)
{
    for (int n=0; n<__N; ++n) {
        __C[n] =__A[n]+__B[0];
    }
}

////////////////////////////////////////////////////////////////////////
// Vector convert to decibels, power, or amplitude.
/*  Maps:  The default maps are used.
 
 These compute:
 
 If Flag is 1:
 alpha = 20;
 If Flag is 0:
 alpha = 10;
 
 for (n = 0; n < N; ++n)
 C[n] = alpha * log10(A[n] / B[0]);
 */
extern void wDSP_vdbcon(
                        const float *__A,
                        wDSP_Stride  __IA,
                        const float *__B,
                        float       *__C,
                        wDSP_Stride  __IC,
                        wDSP_Length  __N,
                        unsigned int __F)
{
    int alpha=10;
    if(__F == 1){
        alpha = 20;
    }else if(__F == 0){
        alpha = 10;
    }
    for (int n=0; n<__N; ++n) {
        __C[n] = alpha * log10(__A[n] / __B[0]);
    }
}
////////////////////////////////////////////////////////////////////////
// Vector-scalar multiply.
/*  Maps:  The default maps are used.
 
 These compute:
 
 for (n = 0; n < N; ++n)
 C[n] = A[n] * B[0];
 */
extern void wDSP_vsmul(
                       const float *__A,
                       wDSP_Stride  __IA,
                       const float *__B,
                       float       *__C,
                       wDSP_Stride  __IC,
                       wDSP_Length  __N)
{
    for (int n=0; n<__N; ++n) {
        __C[n] = __A[n] * __B[0];
    }
}
#ifdef __cplusplus
}
#endif
