//
//  vDSP_wyf.c
//  vDSP_test
//
//  Created by 王逸凡 on 2017/8/31.
//  Copyright © 2017年 wyf. All rights reserved.
//

#include "vDSP_fun.h"

#ifdef __cplusplus
extern "C" {
#endif
////////////////////////////////////////////////////////////////////////
// Convert a complex array to a complex-split array.
/*  Map:

 Pseudocode:     Memory:
 C[n]            C[n*IC/2].real + i * C[n*IC/2].imag
 Z[n]            Z->realp[n*IZ] + i * Z->imagp[n*IZ]

 These compute:

 for (n = 0; n < N; ++n)
 Z[n] = C[n];
 */
extern void vDSP_ctoz(
        const DSPComplex *__C,
        vDSP_Stride __IC,
        const DSPSplitComplex *__Z,
        vDSP_Stride __IZ,
        vDSP_Length __N) {
    for (int n = 0; n < __N; ++n) {
        __Z->realp[n * __IZ] = __C[n * __IC / 2].real;
        __Z->imagp[n * __IZ] = __C[n * __IC / 2].imag;
    }
}

////////////////////////////////////////////////////////////////////////
// Vector magnitudes squared.
/*  Maps:  The default maps are used.

 These compute:

 for (n = 0; n < N; ++n)
 C[n] = |A[n]| ** 2;
 */
extern void vDSP_zvmags(
        const DSPSplitComplex *__A,
        vDSP_Stride __IA,
        float *__C,
        vDSP_Stride __IC,
        vDSP_Length __N) {
    for (int n = 0; n < __N; ++n) {
        __C[n] = powf(__A->realp[n], 2) + powf(__A->imagp[n], 2);
//        LOGD("__C[%d]=%.12f",n,__C[n]);

    }

}

////////////////////////////////////////////////////////////////////////
// Vector-scalar add.
/*  Maps:  The default maps are used.

 These compute:

 for (n = 0; n < N; ++n)
 C[n] = A[n] + B[0];
 */
void vDSP_vsadd(
        const float *__A,
        vDSP_Stride __IA,
        const float *__B,
        float *__C,
        vDSP_Stride __IC,
        vDSP_Length __N) {
    for (int n = 0; n < __N; ++n) {
        __C[n] = __A[n] + __B[0];
    }
}

////////////////////////////////////////////////////////////////////////
// Vector convert to decibels, power, or amplitude.
/*  Maps:  The default maps are used.

 These compute:

 If Flag is 1:
 alpha = 20;
 If Flag is 0:
 alpha = 10;

 for (n = 0; n < N; ++n)
 C[n] = alpha * log10(A[n] / B[0]);
 */
extern void vDSP_vdbcon(
        const float *__A,
        vDSP_Stride __IA,
        const float *__B,
        float *__C,
        vDSP_Stride __IC,
        vDSP_Length __N,
        unsigned int __F) {
    int alpha = 10;
    if (__F == 1) {
        alpha = 20;
    } else if (__F == 0) {
        alpha = 10;
    }
    for (int n = 0; n < __N; ++n) {
        __C[n] = alpha * log10(__A[n] / __B[0]);
    }
}
////////////////////////////////////////////////////////////////////////
// Vector-scalar multiply.
/*  Maps:  The default maps are used.

 These compute:

 for (n = 0; n < N; ++n)
 C[n] = A[n] * B[0];
 */
extern void vDSP_vsmul(
        const float *__A,
        vDSP_Stride __IA,
        const float *__B,
        float *__C,
        vDSP_Stride __IC,
        vDSP_Length __N) {
    for (int n = 0; n < __N; ++n) {
        __C[n] = __A[n] * __B[0];
    }
}

#ifdef __cplusplus
}
#endif