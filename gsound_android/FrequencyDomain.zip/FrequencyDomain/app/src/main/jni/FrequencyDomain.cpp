#include <jni.h>
#include <stdlib.h>
#include <string.h>
#include <SuperpoweredFrequencyDomain.h>
#include <SuperpoweredFFT.h>
#include <AndroidIO/SuperpoweredAndroidAudioIO.h>
#include <SuperpoweredSimple.h>
#include <SuperpoweredCPU.h>
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_AndroidConfiguration.h>

#include <android/log.h>
#define LOG_TAG "System.out"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

#include "queue.h"
#include "bb_freq_util.h"
#include "rscode.h"
#include "vDSP_fun.h"

typedef unsigned int UInt32;
typedef signed int SInt32;
typedef unsigned long Ulong;
typedef float Float32;
typedef double CGFloat;
typedef signed char SInt8;


static SuperpoweredFrequencyDomain *frequencyDomain;
static float *magnitudeLeft, *magnitudeRight, *phaseLeft, *phaseRight, *fifoOutput, *inputBufferFloat;
static int fifoOutputFirstSample, fifoOutputLastSample, stepSize, fifoCapacity;
SuperpoweredAndroidAudioIO *Superpower;
DSPSplitComplex mDspSplitComplex;

#define FFT_LOG_SIZE 12 // 2^11 = 2048
#define SAMPLE_RATE 44100            //采样率
#ifndef CLAMP
#define CLAMP(min, x, max) (x < min ? min : (x > max ? max : x))
#endif

int32_t*			l_fftData;
SInt32* 			fftData;

Ulong               fftLength =0;
Float32             mFFTNormFactor = (Float32)(1.0/(2*4096));
Float32             mAdjust0DB = 1.5849e-13;
//Float32             adjust = 0.1;
Float32             m24BitFracScale = 16777216.0f;


//设置fft的数据，计划从此处将数据读取进来。
void setFFTData(int32_t *FFTDATA ,Ulong LENGTH)
{
    if (LENGTH != fftLength)
    {
        LOGD("*****LENGTH=%ld",LENGTH);
        fftLength = LENGTH;
        fftData = (SInt32 *)(malloc(LENGTH * sizeof(SInt32)));
    }
    LOGD("*****LENGTH=%ld",LENGTH);
    memmove(fftData, FFTDATA, fftLength * sizeof(Float32));
}

static queue _savedBuffer[32];

//设置队列
static void setupQueue() {

    static _Bool flag = 0;

    if (!flag) {

        for (int i = 0; i < 32; i++) {

            queue q = {0};
            _savedBuffer[i] = q;
            //初始化队列
            init_queue(&_savedBuffer[i], 20);
        }
        flag = 1;
    }
}

//尝试解析fft
static void helper(double fftIdx_i, CGFloat interpVal, int length) {

    //先设置好队列
    setupQueue();
    //sampleRate =44100
    float fff = (SAMPLE_RATE / 2.0) * (int) fftIdx_i / (fftLength);

    int code = -1;
    //计算频率至数字，如果符合条件则入队做下一步校验
    if (freq_to_num(fff, &code) == 0 && code >= 0 && code < 32) {

        //enqueue_adv(&_savedBuffer[code], interpVal);

        enqueue(&_savedBuffer[code], interpVal);

        printf("****************%d*********\n", code);
//        LOGD("****************%d*********", code);
    }
}

//根据时间片打印结果
static void  helperResultWithTimeSlice(int length) {
    printf("\ni'm here0\n");
    queue *q17 = &_savedBuffer[17];
    queue *q19 = &_savedBuffer[19];

    printf("queue_item_at_index(q17, 0)=%f \n", queue_item_at_index(q17, 0));
    printf("queue_item_at_index(q17, 1)=%f \n", queue_item_at_index(q17, 1));
    printf("queue_item_at_index(q19, 1)=%f \n", queue_item_at_index(q19, 1));
    printf("queue_item_at_index(q19, 2)=%f \n", queue_item_at_index(q19, 2));
    LOGD("queue_item_at_index(q17, 0)=%f \n", queue_item_at_index(q17, 0));
    LOGD("queue_item_at_index(q17, 1)=%f \n", queue_item_at_index(q17, 1));
    LOGD("queue_item_at_index(q19, 1)=%f \n", queue_item_at_index(q19, 1));
    LOGD("queue_item_at_index(q19, 2)=%f \n", queue_item_at_index(q19, 2));
    if (queue_item_at_index(q17, 0) > 0.0 &&
        queue_item_at_index(q17, 1) > 0.0 &&
        queue_item_at_index(q19, 1) > 0.0 &&
        queue_item_at_index(q19, 2) > 0.0) {

        printf("\ni'm here1\n");

        float minValue = fmin(queue_item_at_index(q17, 2), queue_item_at_index(q19, 3));
        minValue = fmax(minValue, queue_item_at_index(q17, 0) * 0.7);

        float maxValue = fmax(queue_item_at_index(q17, 0), queue_item_at_index(q19, 1)) * 1.85;

        int res[20];
        int rrr[20];
        generate_data(_savedBuffer, 32, res, rrr, 20, minValue, maxValue);

        printf("\n================= start:(19[0]=%f), (17[2]=%f), (19[3]=%f), (17[0]*0.7=%f), (minValue=%f) ==================\n\n",
               queue_item_at_index(q19, 0), queue_item_at_index(q17, 2),
               queue_item_at_index(q19, 3), queue_item_at_index(q17, 0) * 0.7, minValue);
        LOGD("\n================= start:(19[0]=%f), (17[2]=%f), (19[3]=%f), (17[0]*0.7=%f), (minValue=%f) ==================\n\n",
             queue_item_at_index(q19, 0), queue_item_at_index(q17, 2),
             queue_item_at_index(q19, 3), queue_item_at_index(q17, 0) * 0.7, minValue);
        for (int i = 0; i < 20; i++) {
            printf("%02d ", res[i]);
        }

        for (int i = 0; i < 10; i++) {

            int temp;

            temp = rrr[i];
            rrr[i] = rrr[19 - i];
            rrr[19 - i] = temp;
        }

        printf("\n");
//        LOGD("\n");
        for (int i = 0; i < 20; i++) {
            printf("%02d ", rrr[i]);
//            LOGD("%02d ", rrr[i]);
        }

        printf("\n\n");
//        LOGD("\n\n");

        //////////////  RS  ////////////////////////////////

        printf("\ni'm here  rs\n");
        int temp[18];
        int result[18][18];
        int counter = 0;

        for (int i = 0; i < 18; i++) {
            for (int j = 0; j < 18; j++) {

                result[i][j] = -1;
            }
        }

        for (int k = 2; k < 20; k++) {

            printf("~~~~~~~ %02d :17 19 ", k);
//            LOGD("~~~~~~~ %02d :17 19 ", k);
            for (int i = 2, j = 0; i < 20; i++, j++) {

                if (i <= k) {
                    temp[j] = res[i];
                } else {
                    temp[j] = rrr[i];
                }

                printf("%02d ", temp[j]);
//                LOGD("%02d ", temp[j]);
            }

            printf(" ~~~~~~~ ");
//            LOGD(" ~~~~~~~ ");
            RS *rs = init_rs(RS_SYMSIZE, RS_GFPOLY, RS_FCR, RS_PRIM, RS_NROOTS, RS_PAD);
            int eras_pos[RS_TOTAL_LEN] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

            unsigned char data1[RS_TOTAL_LEN];

            for (int i = 0; i < RS_TOTAL_LEN; i++) {
                data1[i] = temp[i];
            }

            int count = decode_rs_char(rs, data1, eras_pos, 0);

            /////////////////////////////////////////////////

            if (count >= 0) {

                for (int m = 0; m < 18; m++) {

                    result[m][counter] = data1[m];
                }

                counter++;
            }

            printf("17 19 ");
//            LOGD("17 19 ");
            for (int i = 0; i < 18; i++) {
                printf("%02d ", data1[i]);
//                LOGD("%02d ", data1[i]);
            }
            printf("    %d\n", count);
//            LOGD("    %d", count);
        }

        int temp_vote[18] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
                             -1};
        int final_result[20] = {17, 19, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
                                -1, -1, -1};

        for (int i = 0; i < 18; i++) {

            for (int j = 0; j < 18; j++) {

                temp_vote[j] = result[i][j];
            }

            vote(temp_vote, 18, &final_result[i + 2]);
        }

        printf("\n ================== final result ================== \n\n");
        LOGD("\n ================== final result ================== \n\n");

        //printf("17-19-00-30-19-13-05-22-12-10-02-02-27-00-20-08-09-21-26-29-\n");

        if (counter == 0) {

            printf("fail!");
            LOGD("fail!");

        } else {
            //final_result为解析出来的结果

            for (int i = 0; i < 20; i++) {

                printf("%02d ", final_result[i]);
                LOGD("%02d ", final_result[i]);

                if (i >= 2 && i <= 11) {

                    char res_char;
                    num_to_char(final_result[i], &res_char);
                }

            }
        }
        /**
         * 此处应该停止接收音频
         * */
        LOGD("final_result[2]=%d",final_result[2]);
        if(   final_result[2]==10
//              && final_result[3]==18  && final_result[4]==10  && final_result[5]==22
//              && final_result[6]==24  && final_result[7]== 2  && final_result[8]==20  && final_result[9]== 4
//              && final_result[10]==19 && final_result[11]== 8 && final_result[12]== 9 && final_result[13]==27
            //     && final_result[14]==18 && final_result[15]==10 && final_result[16]==18 && final_result[17]==17
            //     && final_result[18]==8  && final_result[19]==13
                ){
            Superpower->~SuperpoweredAndroidAudioIO();}
//        Superpower->~SuperpoweredAndroidAudioIO();

        printf("\n\n================  end  ==================\n");
        LOGD("\n\n================  end  ==================\n");
        //printf("\n");
    }
}

/*
static void ComputeFFT(UInt32 mFFTLength,int32_t *outFFTData){
    //    LOGD("numberOfSamples = %d",(unsigned int)numberOfSamples);
    ////将交错复矢量mAudioBuffer的内容复制到分割复矢量mDspSplitComplex单精度。
    vDSP_ctoz((COMPLEX *)inputBufferFloat, 2, &mDspSplitComplex, 1, mFFTLength);
    ////1D Fast Fourier Transforms (In-Place Real)
    SuperpoweredFFTReal(mDspSplitComplex.realp, mDspSplitComplex.imagp, FFT_LOG_SIZE, true);
    ////单精度实矢量标量乘法
    vDSP_vsmul(mDspSplitComplex.realp, 1, &mFFTNormFactor, mDspSplitComplex.realp, 1, mFFTLength);
    ////Zero out the nyquist value
    mDspSplitComplex.imagp[0] = 0.0;
    ////Convert the fft data to dB
    Float32 tmpData[mFFTLength];
    ////平方和 模值。复矢量幅度平方; 单精度。
    vDSP_zvmags(&mDspSplitComplex, 1, tmpData, 1, mFFTLength);
    ////这些函数为向量的每个元素添加一个标量。
    vDSP_vsadd(tmpData, 1, &mAdjust0DB, tmpData, 1, mFFTLength);
    Float32 one = 1;//flag= 1, alpha=20,
    ////向量将功率或振幅转换为分贝; 单精度。
    vDSP_vdbcon(tmpData, 1, &one, tmpData, 1, mFFTLength, 0);
    ////单精度实矢量标量乘法。
    vDSP_vsmul(tmpData, 1, &m24BitFracScale, tmpData, 1, mFFTLength);
    for(UInt32 i=0; i<mFFTLength; ++i){
        outFFTData[i] = (SInt32) tmpData[i];
    }
}
*/

// This is called periodically by the media server.
//周期性调用，来获取音频buffer
static bool audioProcessing(void * __unused clientdata, short int *audioInputOutput,
                            int numberOfSamples, int __unused samplerate) {
    SuperpoweredShortIntToFloat(audioInputOutput, inputBufferFloat, (UInt32)numberOfSamples); // Converting the 16-bit integer samples to 32-bit floating point.
//    frequencyDomain->addInput(inputBufferFloat, (UInt32)numberOfSamples); // Input goes to the frequency domain.
    // Check if we have enough room in the fifo buffer for the output. If not, move the existing audio data back to the buffer's beginning.
//    for(int i=0;i<4096;i++){
//        LOGD("*inputBufferFloat[%d]=%.10f*",i,inputBufferFloat[i]);
//    }
    if (fifoOutputLastSample + stepSize >= fifoCapacity) { // This will be true for every 100th iteration only, so we save precious memory bandwidth.
        int samplesInFifo = fifoOutputLastSample - fifoOutputFirstSample;
        if (samplesInFifo > 0) memmove(fifoOutput, fifoOutput + fifoOutputFirstSample * 2, samplesInFifo * sizeof(float) * 2);
        fifoOutputFirstSample = 0;
        fifoOutputLastSample = samplesInFifo;
    };
    fifoOutputLastSample += stepSize;

    UInt32 mFFTLength = (UInt32)numberOfSamples;
//    vDSP_vsmul(inputBufferFloat, 1, &adjust, inputBufferFloat, 1, mFFTLength*2);

    ////将交错复矢量mAudioBuffer的内容复制到分割复矢量mDspSplitComplex单精度。
    vDSP_ctoz((COMPLEX *)inputBufferFloat, 2, &mDspSplitComplex, 1, mFFTLength);
//    LOGD("***************SUCCESS1***********");
    ////1D Fast Fourier Transforms (In-Place Real)
    SuperpoweredFFTReal(mDspSplitComplex.realp, mDspSplitComplex.imagp, FFT_LOG_SIZE, true);
//    LOGD("***************SUCCESS2***********");
    ///单精度实矢量标量乘法
    vDSP_vsmul(mDspSplitComplex.realp, 1, &mFFTNormFactor, mDspSplitComplex.realp, 1, mFFTLength);
    vDSP_vsmul(mDspSplitComplex.imagp, 1, &mFFTNormFactor, mDspSplitComplex.imagp, 1, mFFTLength);
//    vDSP_vsadd(mDspSplitComplex.realp, 1, &adjust, mDspSplitComplex.realp, 1, mFFTLength);
    float sum_realp=0,sum_imagp=0;
    for (int i = 0; i < mFFTLength; ++i) {
        sum_realp +=mDspSplitComplex.realp[i];
        sum_imagp +=mDspSplitComplex.imagp[i];
    }
    LOGD("***************////////////////***********");
    LOGD("avg_realp=%.10f****avg_imagp=%.10f",sum_realp/mFFTLength,sum_imagp/mFFTLength);
    LOGD("***************////////////////***********");
//    LOGD("***************SUCCESS3***********");
    ////Zero out the nyquist value
    mDspSplitComplex.imagp[0] = 0.0;
//    LOGD("***************SUCCESS4***********");
    ////Convert the fft data to dB
    Float32 tmpData[mFFTLength] ;
//    for(int i=0;i<2048;i++)   tmpData[i]=0;
//    LOGD("***************SUCCESS5***********");
    ////平方和 模值。复矢量幅度平方; 单精度。
    vDSP_zvmags(&mDspSplitComplex, 1, tmpData, 1, mFFTLength);
//    LOGD("***************SUCCESS6***********");
    ////这些函数为向量的每个元素添加一个标量。
    vDSP_vsadd(tmpData, 1, &mAdjust0DB, tmpData, 1, mFFTLength);
//    LOGD("***************SUCCESS7***********");
    Float32 one = 1;//flag= 1, alpha=20,
    ////向量将功率或振幅转换为分贝; 单精度。
    vDSP_vdbcon(tmpData, 1, &one, tmpData, 1, mFFTLength, 0);
//    LOGD("***************SUCCESS8***********");

    ////单精度实矢量标量乘法。
    vDSP_vsmul(tmpData, 1, &m24BitFracScale, tmpData, 1, mFFTLength);
//    LOGD("***************SUCCESS9***********");
    for(UInt32 i=0; i<mFFTLength; ++i){
//        LOGD("tmpData[%d]=%.10f",i,tmpData[i]);
        l_fftData[i] = (SInt32) tmpData[i];
    }

    // In the frequency domain we are working with 1024 magnitudes and phases for every channel (left, right), if the fft size is 2048.
    if (1==1) {

        LOGD("********START********");
        setFFTData(l_fftData,(UInt32)numberOfSamples);
        LOGD("***************SUCCESS10***********");
        if (1 == 1) {
            int i;
            for (i = 0; i < 32; i++) {

                unsigned int freq;
                int fftIdx;

                num_to_freq(i, &freq);
                fftIdx = (int) (freq / (SAMPLE_RATE / 2.0) * fftLength);

                double fftIdx_i, fftIdx_f;
                //fftIdx为原数，fftIdx_f为小数部分，fftIdx_i为整数部分
                fftIdx_f = modf(fftIdx, &fftIdx_i);

                SInt8 fft_l, fft_r;
                CGFloat fft_l_fl, fft_r_fl;
                CGFloat interpVal;

                //将准备好的fft数据，进行加工，准备傅里叶变换
                fft_l = (fftData[(int)fftIdx_i] & 0xFF000000) >> 24;
                fft_r = (fftData[(int)fftIdx_i + 1] & 0xFF000000) >> 24;
                //除以64.是将幅值进行归一化处理。
                fft_l_fl = (CGFloat)(fft_l + 80) / 64.;
                fft_r_fl = (CGFloat)(fft_r + 80) / 64.;

                printf("fftLength=%lu, fft_l_fl=%f , fft_r_fl=%f ,fftIdx_i=%d ", fftLength, fft_l_fl,
                       fft_r_fl, (int) fftIdx_i);
//                LOGD("fftLength=%lu, fft_l_fl=%f , fft_r_fl=%f ,fftIdx_i=%d ", fftLength, fft_l_fl, fft_r_fl, (int) fftIdx_i);
                interpVal = fft_l_fl * (1. - fftIdx_f) + fft_r_fl * fftIdx_f;
                interpVal = sqrt(CLAMP(0., interpVal, 1.));

                printf("interpVal=%lf\n", interpVal);
                //////////////////////////////////////////////////////////////////
                helper(fftIdx, interpVal, 6);
                //////////////////////////////////////////////////////////////////
            }
        }
        //////////////////////////////////////////////////////////////////
        helperResultWithTimeSlice(6);
        //////////////////////////////////////////////////////////////////

//        free(fftData);
        LOGD("********END********");

    };

    // If we have enough samples in the fifo output buffer, pass them to the audio output.
    if (fifoOutputLastSample - fifoOutputFirstSample >= numberOfSamples) {
        SuperpoweredFloatToShortInt(fifoOutput + fifoOutputFirstSample * 2, audioInputOutput, (unsigned int)numberOfSamples);
        fifoOutputFirstSample += numberOfSamples;
        return true;
    } else return false;
}

//jni函数声明并且实现
extern "C" JNIEXPORT void Java_com_superpowered_frequencydomain_MainActivity_FrequencyDomain(JNIEnv * __unused javaEnvironment, jobject __unused obj, jint samplerate, jint buffersize) {

    // Time domain result goes into a FIFO (first-in, first-out) buffer
    fifoOutputFirstSample = fifoOutputLastSample = 0;
    fifoCapacity = stepSize * 100; // Let's make the fifo's size 100 times more than the step size, so we save memory bandwidth.
    fifoOutput = (float *)malloc(fifoCapacity * sizeof(float) * 2 + 128);
    inputBufferFloat = (Float32 *)malloc(buffersize * sizeof(Float32) * 2);
    mDspSplitComplex.realp = (Float32 *) malloc(buffersize * sizeof(Float32));
    mDspSplitComplex.imagp = (Float32 *) malloc(buffersize * sizeof(Float32));

    l_fftData = (int32_t*)malloc(buffersize * sizeof(int32_t));
    LOGD("buffersize=%d:",buffersize);
    LOGD("inputBufferFloat长度为：%d:",(int)(buffersize * sizeof(float) * 2 + 128));
    SuperpoweredCPU::setSustainedPerformanceMode(true);
    Superpower = new SuperpoweredAndroidAudioIO(samplerate, buffersize, true, false, audioProcessing, NULL, -1, SL_ANDROID_STREAM_MEDIA, buffersize * 2); // Start audio input/output.

}

