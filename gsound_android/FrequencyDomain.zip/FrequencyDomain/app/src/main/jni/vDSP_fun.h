//
//  vDSP_wyf.h
//  vDSP_test
//
//  Created by 王逸凡 on 2017/8/31.
//  Copyright © 2017年 wyf. All rights reserved.
//

#ifndef FREQUENCYDOMAIN_VDSP_FUN_H
#define FREQUENCYDOMAIN_VDSP_FUN_H


#include <stdio.h>
#include <math.h>
#include <android/log.h>
#define LOG_TAG "System.out"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#ifdef __cplusplus
extern "C" {
#endif
/*  Define types:

 vDSP_Length for numbers of elements in arrays and for indices of
 elements in arrays.  (It is also used for the base-two logarithm of
 numbers of elements, although a much smaller type is suitable for
 that.)

 vDSP_Stride for differences of indices of elements (which of course
 includes strides).
 */
typedef unsigned long vDSP_Length;
typedef long vDSP_Stride;
/*  A DSPComplex is a pair of float values that represents a complex value.
 */
typedef struct DSPComplex {
    float real;
    float imag;
} DSPComplex;
////////////////////////////////////////////////////////////////////////
/*  A DSPSplitComplex is a structure containing two pointers, each to an array of float.  This represents arrays of complex values, with the real components of the values stored in one array and the imaginary components of the values stored in a separate array.
 */
typedef struct DSPSplitComplex {
    float *realp;
    float *imagp;
} DSPSplitComplex;

typedef DSPComplex COMPLEX;
typedef DSPSplitComplex COMPLEX_SPLIT;

////////////////////////////////////////////////////////////////////////
// Convert a complex array to a complex-split array.
/*  Map:

 Pseudocode:     Memory:
 C[n]            C[n*IC/2].real + i * C[n*IC/2].imag
 Z[n]            Z->realp[n*IZ] + i * Z->imagp[n*IZ]

 These compute:

 for (n = 0; n < N; ++n)
 Z[n] = C[n];
 */
extern void vDSP_ctoz(
        const DSPComplex *__C,
        vDSP_Stride __IC,
        const DSPSplitComplex *__Z,
        vDSP_Stride __IZ,
        vDSP_Length __N);
////////////////////////////////////////////////////////////////////////
// Vector-scalar multiply.
/*  Maps:  The default maps are used.

 These compute:

 for (n = 0; n < N; ++n)
 C[n] = A[n] * B[0];
 */
extern void vDSP_vsmul(
        const float *__A,
        vDSP_Stride __IA,
        const float *__B,
        float *__C,
        vDSP_Stride __IC,
        vDSP_Length __N);
////////////////////////////////////////////////////////////////////////
// Vector magnitudes squared.
/*  Maps:  The default maps are used.

 These compute:

 for (n = 0; n < N; ++n)
 C[n] = |A[n]| ** 2;
 */
extern void vDSP_zvmags(
        const DSPSplitComplex *__A,
        vDSP_Stride __IA,
        float *__C,
        vDSP_Stride __IC,
        vDSP_Length __N);
////////////////////////////////////////////////////////////////////////
// Vector-scalar add.
/*  Maps:  The default maps are used.

 These compute:

 for (n = 0; n < N; ++n)
 C[n] = A[n] + B[0];
 */
extern void vDSP_vsadd(
        const float *__A,
        vDSP_Stride __IA,
        const float *__B,
        float *__C,
        vDSP_Stride __IC,
        vDSP_Length __N);
////////////////////////////////////////////////////////////////////////
// Vector convert to decibels, power, or amplitude.
/*  Maps:  The default maps are used.

 These compute:

 If Flag is 1:
 alpha = 20;
 If Flag is 0:
 alpha = 10;

 for (n = 0; n < N; ++n)
 C[n] = alpha * log10(A[n] / B[0]);
 */
extern void vDSP_vdbcon(
        const float *__A,
        vDSP_Stride __IA,
        const float *__B,
        float *__C,
        vDSP_Stride __IC,
        vDSP_Length __N,
        unsigned int __F);
////////////////////////////////////////////////////////////////////////

#ifdef __cplusplus
}
#endif

#endif //FREQUENCYDOMAIN_VDSP_FUN_H
